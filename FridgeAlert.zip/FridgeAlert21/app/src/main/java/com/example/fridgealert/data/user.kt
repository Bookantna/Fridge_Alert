package com.example.fridgealert.data

data class user(
    var username: String? = null,
    var email: String? = null,
    var password: String? = null
)
